package com.example.buraktatar.rhbr;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
    Button but1,btn2;
    EditText ad;
    TextView tc;
    EditText numara;
    EditText soyad;
    private database vt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vt=new database(this);
        but1=(Button)findViewById(R.id.button);
        tc=(TextView)findViewById(R.id.textView) ;
        ad=(EditText)findViewById(R.id.editText);
        soyad=(EditText)findViewById(R.id.editText2);
        btn2=(Button)findViewById(R.id.button2);
        numara=(EditText)findViewById(R.id.editText3);

        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    SQLiteDatabase db=vt.getWritableDatabase();
                    ContentValues cv=new ContentValues();
                    cv.put("ad",ad.getText().toString());
                    cv.put( "soyad",soyad.getText().toString());
                    cv.put( "numara"  ,numara.getText().toString()  );
                    db.insert("rehber",null,cv);
                    Toast.makeText(getApplicationContext(),"ekleme yapıldı",Toast.LENGTH_LONG).show();
                }catch (Exception ex){
                    Toast.makeText(getApplicationContext(),"olmadu"+ex.getMessage(),Toast.LENGTH_LONG).show();
                }

            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=getData();
                tc.setText(a);
            }
        });
    }

    public String getData(){
        SQLiteDatabase db = vt.getWritableDatabase();
        String[] columns = {"ad","soyad","numara"};
        Cursor cursor =db.query("rehber",columns,null,null,null,null,null);
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext())
        {
            String cid =cursor.getString(cursor.getColumnIndex("ad"));
            String name =cursor.getString(cursor.getColumnIndex("soyad"));
            String  password =cursor.getString(cursor.getColumnIndex("numara"));
            buffer.append(cid+"     "+ name +"      "+ "     "+password+" \n");

        }
        return buffer.toString();
    }


}
